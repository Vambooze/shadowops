fx_version 'cerulean'
games { 'common' }

author '8null <contact@8null.com>'
description '[fivem-lsm.com] loading screen powered by fivem-lsm.com'
version '3.0.1'

server_script 'userdata.lua'

loadscreen 'https://live.fivem-lsm.com/s/?i=98450987'