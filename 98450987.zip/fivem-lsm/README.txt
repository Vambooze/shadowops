Installation:

Upload the fivem-lsm folder to your server's resources folder.
After that edit your server.cfg and add 'start fivem-lsm' to the bottom of the file.
Now, save and upload your file and restart your server.