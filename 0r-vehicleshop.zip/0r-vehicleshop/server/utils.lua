CustomInventory = {}

---@param source number Player server id
---@param itemName string item name
---@return number itemCount
function CustomInventory.GetItemCount(source, itemName)
    -- local itemCount = exports.["CustomInventory"]:GetItemCount(?, ?)
    -- return itemCount
end

---@param source number Player server id
---@param itemName string
---@param itemCount number
---@return boolean result
function CustomInventory.RemoveItem(source, itemName, itemCount)
    -- exports.["CustomInventory"]:RemoveItem(?, ?)
end
